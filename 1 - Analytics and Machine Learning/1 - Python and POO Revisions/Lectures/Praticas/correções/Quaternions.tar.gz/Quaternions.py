
# coding: utf-8

# In[2]:

import math


# In[1]:

class Quaternion:
    def __init__(self, q1, q2, q3, q4):
        self.__a = q1
        self.__b = q2
        self.__c = q3
        self.__d = q4
 
    def conjugado(self):
        return Quaternion(self.__a, -self.__b, -self.__c, -self.__d)
         
    
    def __add__(self, other):
        return Quaternion(self.__a + other.__a,self.__b + other.__b, self.__c + other.__c, self.__d + other.__d)
    
    def __mul__(self, other):
        
        if(isinstance(other,int) or isinstance(other, float)):
            return Quaternion(other*self.__a, other*self.__b, other*self.__c, other*self.__d)
        
        elif (other == self.conjugado()):
            return int(self.__a**2 + self.__b**2 + self.__c**2 + self.__d**2)

        else:
            a = self.__a*other.__a - self.__b*other.__b - self.__c* other.__c - self.__d * other.__d
            b = self.__a* other.__b + self.__b*other.__a + self.__c*other.__d - self.__d*other.__c
            c = self.__a*other.__c - self.__b*other.__d + self.__c*other.__a + self.__d*other.__b
            d = self.__a*other.__d + self.__b*other.__c - self.__c*other.__b + self.__d*other.__a
        
        return Quaternion(a, b, c, d)
        
    def __abs__(self):
        
        qq = (self.__a**2 + self.__b**2 + self.__c**2 + self.__d**2)
        absoluto = math.sqrt(qq)
        return absoluto

    def inverso(self):
        
        qq = (self.__a**2 + self.__b**2 + self.__c**2 + self.__d**2)
        
        inverte = self.conjugado()*(1 / qq)
        return inverte
    
    def __eq__(self, other):
        return (self.__a == other.__a and self.__b == other.__b and self.__c == other.__c and self.__d == other.__d)
        
       
    def __truediv__(self, other):
        
        inv = other.inverso()
        
        if(isinstance(other,int) or isinstance(other, float)):
            
            return Quaternion(self.__a/other , self.__b/other , self.__c/other , self.__d/other)
        
        else:
            
            return Quaternion(self.__a * inv.__a, self.__b *inv.__b, self.__c *inv.__c, self.__d*inv.__d)
        
    def __str__(self):
        
        string = str(self.__a)
        
        if(self.__b < 0):
            string += str(self.__b)+"i"
            
        else: string += "+" + str(self.__b) +"i"    
       
        if(self.__c < 0):
            string += str(self.__c)+ "j"
          
        else: string += "+" + str(self.__c)+ "j"
            
        if(self.__d < 0):
            string += str(self.__d)+ "k"
            
        else: string += "+" + str(self.__d)+ "k" 
            
        return string    
    
    def __sub__(self, other):
        return Quaternion(self.__a - other.__a,self.__b - other.__b, self.__c - other.__c, self.__d - other.__d)
    
    def __pow__(self, other):
        return Quaternion(self.__a**other, self.__b**other, self.__c**other, self.__d**other)
    
    def rotaçao(self, other, ang):
        
        if(other.__a == 0): #checa se é um vetor, ou seja, um quaternion com parte real = 0
            
            x = other.__b**2 + other.__c**2 + other.__d**2  
            modulo = math.sqrt(x) 
            f = ang/2
            r = Quaternion(math.cos(f), ((math.sin(f)/modulo)*other.__b), ((math.sin(f)/modulo)*other.__c),((math.sin(f)/modulo)*other.__d))
            inv = r.inverso()
            plinha= r*self*inv
            return plinha
    
        else:
            return False 
        


# In[ ]:



