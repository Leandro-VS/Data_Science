SELECT *

FROM tb_book_sellers

where seller_id = 'cca3071e3e9bb7d12640c9fbe2301306'

order by dt_ref