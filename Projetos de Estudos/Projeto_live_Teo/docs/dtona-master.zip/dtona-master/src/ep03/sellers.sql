select *
from tb_sellers